
package Herencia;

public class Principal {
    
    public static void main (String[] args){
        Estudiante estudiante1 = new  Estudiante (123 , 3.5f , "Andres" , "Ruiz" , 29);
        
        estudiante1.mostrarDatos();
        System.out.println("");
    }
    
}
