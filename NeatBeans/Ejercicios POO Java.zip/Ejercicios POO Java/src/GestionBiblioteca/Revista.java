/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionBiblioteca;

/**
 *
 * @author Treisi Robles
 */
public class Revista extends Material{
    private int numeroEdicion;
    
    public Revista(String titulo , String autor , int anoPublicacion , int numeroEdicion){
        super(titulo , autor , anoPublicacion);
        this.numeroEdicion = numeroEdicion;
    }
    
    public int getEdicion (){
        return numeroEdicion;
    }
    
    @Override
    public void mostrarInformacion(){
        super.mostrarInformacion();
        System.out.println("Numero de edicion: " + numeroEdicion);
    }
}
