/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionBiblioteca;

/**
 *
 * @author Treisi Robles
 */
public class Libro extends Material{
    private String genero;
    
    public Libro(String titulo , String autor , int anoPublicacion , String genero){
        super(titulo , autor , anoPublicacion);
        this.genero = genero;
    }
    
    public String getGenero(){
        return genero;
    }
    
    @Override
    public void mostrarInformacion(){
        super.mostrarInformacion();
        System.out.println("Genero: " + genero);
    }
}
