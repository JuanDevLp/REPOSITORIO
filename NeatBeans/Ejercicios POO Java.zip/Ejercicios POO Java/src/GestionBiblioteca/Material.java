/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GestionBiblioteca;

/**
 *
 * @author Treisi Robles
 */
public class Material {
    private String titulo;
    private String autor;
    private int anoPublicacion;
    
    public Material(String titulo , String autor , int anoPublicacion){
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacion = anoPublicacion;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public String getAutor(){
        return autor;
    }
    
    public int getAnoPublicacion(){
        return anoPublicacion;
    }
    
    public void mostrarInformacion(){
        System.out.println("Titulo: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Año de publicación " + anoPublicacion);
    }
}
