/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Encapsulamiento;

/**
 *
 * @author SENA
 */
public class Principal {
     public static void main(String[] args) {
         
        CuentaBancaria cuenta = new CuentaBancaria("0000001", "Juan Lopez", 1000);

        System.out.println("Numero de cuenta: " + cuenta.getNumeroCuenta());
        System.out.println("Titular: " + cuenta.getNombreTitular());
        System.out.println("Saldo: " + cuenta.getSaldo());

        cuenta.depositar(500);
        System.out.println("Saldo despues del deposito: " + cuenta.getSaldo());

        cuenta.retirar(700);
        System.out.println("Saldo despues del retiro: " + cuenta.getSaldo());

        cuenta.setNombreTitular("Juan D. Lopez");
        System.out.println("Nuevo titular: " + cuenta.getNombreTitular());
        
    }
}
